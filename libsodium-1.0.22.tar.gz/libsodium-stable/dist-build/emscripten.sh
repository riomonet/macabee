#! /bin/sh

export MAKE_FLAGS='-j4'
export EXPORTED_FUNCTIONS_STANDARD='["_malloc","_free","_crypto_aead_aegis128l_abytes","_crypto_aead_aegis128l_decrypt","_crypto_aead_aegis128l_decrypt_detached","_crypto_aead_aegis128l_encrypt","_crypto_aead_aegis128l_encrypt_detached","_crypto_aead_aegis128l_keybytes","_crypto_aead_aegis128l_keygen","_crypto_aead_aegis128l_messagebytes_max","_crypto_aead_aegis128l_npubbytes","_crypto_aead_aegis128l_nsecbytes","_crypto_aead_aegis256_abytes","_crypto_aead_aegis256_decrypt","_crypto_aead_aegis256_decrypt_detached","_crypto_aead_aegis256_encrypt","_crypto_aead_aegis256_encrypt_detached","_crypto_aead_aegis256_keybytes","_crypto_aead_aegis256_keygen","_crypto_aead_aegis256_messagebytes_max","_crypto_aead_aegis256_npubbytes","_crypto_aead_aegis256_nsecbytes","_crypto_aead_aes256gcm_is_available","_crypto_aead_chacha20poly1305_abytes","_crypto_aead_chacha20poly1305_decrypt","_crypto_aead_chacha20poly1305_decrypt_detached","_crypto_aead_chacha20poly1305_encrypt","_crypto_aead_chacha20poly1305_encrypt_detached","_crypto_aead_chacha20poly1305_ietf_abytes","_crypto_aead_chacha20poly1305_ietf_decrypt","_crypto_aead_chacha20poly1305_ietf_decrypt_detached","_crypto_aead_chacha20poly1305_ietf_encrypt","_crypto_aead_chacha20poly1305_ietf_encrypt_detached","_crypto_aead_chacha20poly1305_ietf_keybytes","_crypto_aead_chacha20poly1305_ietf_keygen","_crypto_aead_chacha20poly1305_ietf_messagebytes_max","_crypto_aead_chacha20poly1305_ietf_npubbytes","_crypto_aead_chacha20poly1305_ietf_nsecbytes","_crypto_aead_chacha20poly1305_keybytes","_crypto_aead_chacha20poly1305_keygen","_crypto_aead_chacha20poly1305_messagebytes_max","_crypto_aead_chacha20poly1305_npubbytes","_crypto_aead_chacha20poly1305_nsecbytes","_crypto_aead_xchacha20poly1305_ietf_abytes","_crypto_aead_xchacha20poly1305_ietf_decrypt","_crypto_aead_xchacha20poly1305_ietf_decrypt_detached","_crypto_aead_xchacha20poly1305_ietf_encrypt","_crypto_aead_xchacha20poly1305_ietf_encrypt_detached","_crypto_aead_xchacha20poly1305_ietf_keybytes","_crypto_aead_xchacha20poly1305_ietf_keygen","_crypto_aead_xchacha20poly1305_ietf_messagebytes_max","_crypto_aead_xchacha20poly1305_ietf_npubbytes","_crypto_aead_xchacha20poly1305_ietf_nsecbytes","_crypto_auth","_crypto_auth_bytes","_crypto_auth_keybytes","_crypto_auth_keygen","_crypto_auth_verify","_crypto_box_beforenm","_crypto_box_beforenmbytes","_crypto_box_detached","_crypto_box_detached_afternm","_crypto_box_easy","_crypto_box_easy_afternm","_crypto_box_keypair","_crypto_box_macbytes","_crypto_box_messagebytes_max","_crypto_box_noncebytes","_crypto_box_open_detached","_crypto_box_open_detached_afternm","_crypto_box_open_easy","_crypto_box_open_easy_afternm","_crypto_box_publickeybytes","_crypto_box_seal","_crypto_box_seal_open","_crypto_box_sealbytes","_crypto_box_secretkeybytes","_crypto_box_seed_keypair","_crypto_box_seedbytes","_crypto_generichash","_crypto_generichash_bytes","_crypto_generichash_bytes_max","_crypto_generichash_bytes_min","_crypto_generichash_final","_crypto_generichash_init","_crypto_generichash_keybytes","_crypto_generichash_keybytes_max","_crypto_generichash_keybytes_min","_crypto_generichash_keygen","_crypto_generichash_statebytes","_crypto_generichash_update","_crypto_hash","_crypto_hash_bytes","_crypto_hash_sha3256","_crypto_hash_sha3256_bytes","_crypto_hash_sha3256_final","_crypto_hash_sha3256_init","_crypto_hash_sha3256_statebytes","_crypto_hash_sha3256_update","_crypto_hash_sha3512","_crypto_hash_sha3512_bytes","_crypto_hash_sha3512_final","_crypto_hash_sha3512_init","_crypto_hash_sha3512_statebytes","_crypto_hash_sha3512_update","_crypto_ipcrypt_bytes","_crypto_ipcrypt_decrypt","_crypto_ipcrypt_encrypt","_crypto_ipcrypt_keybytes","_crypto_ipcrypt_keygen","_crypto_ipcrypt_nd_decrypt","_crypto_ipcrypt_nd_encrypt","_crypto_ipcrypt_nd_inputbytes","_crypto_ipcrypt_nd_keybytes","_crypto_ipcrypt_nd_keygen","_crypto_ipcrypt_nd_outputbytes","_crypto_ipcrypt_nd_tweakbytes","_crypto_ipcrypt_ndx_decrypt","_crypto_ipcrypt_ndx_encrypt","_crypto_ipcrypt_ndx_inputbytes","_crypto_ipcrypt_ndx_keybytes","_crypto_ipcrypt_ndx_keygen","_crypto_ipcrypt_ndx_outputbytes","_crypto_ipcrypt_ndx_tweakbytes","_crypto_ipcrypt_pfx_bytes","_crypto_ipcrypt_pfx_decrypt","_crypto_ipcrypt_pfx_encrypt","_crypto_ipcrypt_pfx_keybytes","_crypto_ipcrypt_pfx_keygen","_crypto_kdf_bytes_max","_crypto_kdf_bytes_min","_crypto_kdf_contextbytes","_crypto_kdf_derive_from_key","_crypto_kdf_hkdf_sha256_bytes_max","_crypto_kdf_hkdf_sha256_bytes_min","_crypto_kdf_hkdf_sha256_expand","_crypto_kdf_hkdf_sha256_extract","_crypto_kdf_hkdf_sha256_extract_final","_crypto_kdf_hkdf_sha256_extract_init","_crypto_kdf_hkdf_sha256_extract_update","_crypto_kdf_hkdf_sha256_keybytes","_crypto_kdf_hkdf_sha256_keygen","_crypto_kdf_hkdf_sha256_statebytes","_crypto_kdf_hkdf_sha512_bytes_max","_crypto_kdf_hkdf_sha512_bytes_min","_crypto_kdf_hkdf_sha512_expand","_crypto_kdf_hkdf_sha512_extract","_crypto_kdf_hkdf_sha512_extract_final","_crypto_kdf_hkdf_sha512_extract_init","_crypto_kdf_hkdf_sha512_extract_update","_crypto_kdf_hkdf_sha512_keybytes","_crypto_kdf_hkdf_sha512_keygen","_crypto_kdf_hkdf_sha512_statebytes","_crypto_kdf_keybytes","_crypto_kdf_keygen","_crypto_kem_ciphertextbytes","_crypto_kem_dec","_crypto_kem_enc","_crypto_kem_keypair","_crypto_kem_mlkem768_ciphertextbytes","_crypto_kem_mlkem768_dec","_crypto_kem_mlkem768_enc","_crypto_kem_mlkem768_enc_deterministic","_crypto_kem_mlkem768_keypair","_crypto_kem_mlkem768_publickeybytes","_crypto_kem_mlkem768_secretkeybytes","_crypto_kem_mlkem768_seed_keypair","_crypto_kem_mlkem768_seedbytes","_crypto_kem_mlkem768_sharedsecretbytes","_crypto_kem_primitive","_crypto_kem_publickeybytes","_crypto_kem_secretkeybytes","_crypto_kem_seed_keypair","_crypto_kem_seedbytes","_crypto_kem_sharedsecretbytes","_crypto_kem_xwing_ciphertextbytes","_crypto_kem_xwing_dec","_crypto_kem_xwing_enc","_crypto_kem_xwing_enc_deterministic","_crypto_kem_xwing_keypair","_crypto_kem_xwing_publickeybytes","_crypto_kem_xwing_secretkeybytes","_crypto_kem_xwing_seed_keypair","_crypto_kem_xwing_seedbytes","_crypto_kem_xwing_sharedsecretbytes","_crypto_kx_client_session_keys","_crypto_kx_keypair","_crypto_kx_publickeybytes","_crypto_kx_secretkeybytes","_crypto_kx_seed_keypair","_crypto_kx_seedbytes","_crypto_kx_server_session_keys","_crypto_kx_sessionkeybytes","_crypto_scalarmult","_crypto_scalarmult_base","_crypto_scalarmult_bytes","_crypto_scalarmult_scalarbytes","_crypto_secretbox_detached","_crypto_secretbox_easy","_crypto_secretbox_keybytes","_crypto_secretbox_keygen","_crypto_secretbox_macbytes","_crypto_secretbox_messagebytes_max","_crypto_secretbox_noncebytes","_crypto_secretbox_open_detached","_crypto_secretbox_open_easy","_crypto_secretstream_xchacha20poly1305_abytes","_crypto_secretstream_xchacha20poly1305_headerbytes","_crypto_secretstream_xchacha20poly1305_init_pull","_crypto_secretstream_xchacha20poly1305_init_push","_crypto_secretstream_xchacha20poly1305_keybytes","_crypto_secretstream_xchacha20poly1305_keygen","_crypto_secretstream_xchacha20poly1305_messagebytes_max","_crypto_secretstream_xchacha20poly1305_pull","_crypto_secretstream_xchacha20poly1305_push","_crypto_secretstream_xchacha20poly1305_rekey","_crypto_secretstream_xchacha20poly1305_statebytes","_crypto_secretstream_xchacha20poly1305_tag_final","_crypto_secretstream_xchacha20poly1305_tag_message","_crypto_secretstream_xchacha20poly1305_tag_push","_crypto_secretstream_xchacha20poly1305_tag_rekey","_crypto_shorthash","_crypto_shorthash_bytes","_crypto_shorthash_keybytes","_crypto_shorthash_keygen","_crypto_sign","_crypto_sign_bytes","_crypto_sign_detached","_crypto_sign_ed25519_pk_to_curve25519","_crypto_sign_ed25519_sk_to_curve25519","_crypto_sign_final_create","_crypto_sign_final_verify","_crypto_sign_init","_crypto_sign_keypair","_crypto_sign_messagebytes_max","_crypto_sign_open","_crypto_sign_publickeybytes","_crypto_sign_secretkeybytes","_crypto_sign_seed_keypair","_crypto_sign_seedbytes","_crypto_sign_statebytes","_crypto_sign_update","_crypto_sign_verify_detached","_crypto_xof_shake128","_crypto_xof_shake128_blockbytes","_crypto_xof_shake128_domain_standard","_crypto_xof_shake128_init","_crypto_xof_shake128_init_with_domain","_crypto_xof_shake128_squeeze","_crypto_xof_shake128_statebytes","_crypto_xof_shake128_update","_crypto_xof_shake256","_crypto_xof_shake256_blockbytes","_crypto_xof_shake256_domain_standard","_crypto_xof_shake256_init","_crypto_xof_shake256_init_with_domain","_crypto_xof_shake256_squeeze","_crypto_xof_shake256_statebytes","_crypto_xof_shake256_update","_crypto_xof_turboshake128","_crypto_xof_turboshake128_blockbytes","_crypto_xof_turboshake128_domain_standard","_crypto_xof_turboshake128_init","_crypto_xof_turboshake128_init_with_domain","_crypto_xof_turboshake128_squeeze","_crypto_xof_turboshake128_statebytes","_crypto_xof_turboshake128_update","_crypto_xof_turboshake256","_crypto_xof_turboshake256_blockbytes","_crypto_xof_turboshake256_domain_standard","_crypto_xof_turboshake256_init","_crypto_xof_turboshake256_init_with_domain","_crypto_xof_turboshake256_squeeze","_crypto_xof_turboshake256_statebytes","_crypto_xof_turboshake256_update","_randombytes","_randombytes_buf","_randombytes_buf_deterministic","_randombytes_close","_randombytes_random","_randombytes_seedbytes","_randombytes_stir","_randombytes_uniform","_sodium_base64_encoded_len","_sodium_base642bin","_sodium_bin2base64","_sodium_bin2hex","_sodium_bin2ip","_sodium_hex2bin","_sodium_init","_sodium_ip2bin","_sodium_library_minimal","_sodium_library_version_major","_sodium_library_version_minor","_sodium_pad","_sodium_unpad","_sodium_version_string"]'
export EXPORTED_FUNCTIONS_SUMO='["_malloc","_free","_crypto_aead_aegis128l_abytes","_crypto_aead_aegis128l_decrypt","_crypto_aead_aegis128l_decrypt_detached","_crypto_aead_aegis128l_encrypt","_crypto_aead_aegis128l_encrypt_detached","_crypto_aead_aegis128l_keybytes","_crypto_aead_aegis128l_keygen","_crypto_aead_aegis128l_messagebytes_max","_crypto_aead_aegis128l_npubbytes","_crypto_aead_aegis128l_nsecbytes","_crypto_aead_aegis256_abytes","_crypto_aead_aegis256_decrypt","_crypto_aead_aegis256_decrypt_detached","_crypto_aead_aegis256_encrypt","_crypto_aead_aegis256_encrypt_detached","_crypto_aead_aegis256_keybytes","_crypto_aead_aegis256_keygen","_crypto_aead_aegis256_messagebytes_max","_crypto_aead_aegis256_npubbytes","_crypto_aead_aegis256_nsecbytes","_crypto_aead_aes256gcm_is_available","_crypto_aead_chacha20poly1305_abytes","_crypto_aead_chacha20poly1305_decrypt","_crypto_aead_chacha20poly1305_decrypt_detached","_crypto_aead_chacha20poly1305_encrypt","_crypto_aead_chacha20poly1305_encrypt_detached","_crypto_aead_chacha20poly1305_ietf_abytes","_crypto_aead_chacha20poly1305_ietf_decrypt","_crypto_aead_chacha20poly1305_ietf_decrypt_detached","_crypto_aead_chacha20poly1305_ietf_encrypt","_crypto_aead_chacha20poly1305_ietf_encrypt_detached","_crypto_aead_chacha20poly1305_ietf_keybytes","_crypto_aead_chacha20poly1305_ietf_keygen","_crypto_aead_chacha20poly1305_ietf_messagebytes_max","_crypto_aead_chacha20poly1305_ietf_npubbytes","_crypto_aead_chacha20poly1305_ietf_nsecbytes","_crypto_aead_chacha20poly1305_keybytes","_crypto_aead_chacha20poly1305_keygen","_crypto_aead_chacha20poly1305_messagebytes_max","_crypto_aead_chacha20poly1305_npubbytes","_crypto_aead_chacha20poly1305_nsecbytes","_crypto_aead_xchacha20poly1305_ietf_abytes","_crypto_aead_xchacha20poly1305_ietf_decrypt","_crypto_aead_xchacha20poly1305_ietf_decrypt_detached","_crypto_aead_xchacha20poly1305_ietf_encrypt","_crypto_aead_xchacha20poly1305_ietf_encrypt_detached","_crypto_aead_xchacha20poly1305_ietf_keybytes","_crypto_aead_xchacha20poly1305_ietf_keygen","_crypto_aead_xchacha20poly1305_ietf_messagebytes_max","_crypto_aead_xchacha20poly1305_ietf_npubbytes","_crypto_aead_xchacha20poly1305_ietf_nsecbytes","_crypto_auth","_crypto_auth_bytes","_crypto_auth_hmacsha256","_crypto_auth_hmacsha256_bytes","_crypto_auth_hmacsha256_final","_crypto_auth_hmacsha256_init","_crypto_auth_hmacsha256_keybytes","_crypto_auth_hmacsha256_keygen","_crypto_auth_hmacsha256_statebytes","_crypto_auth_hmacsha256_update","_crypto_auth_hmacsha256_verify","_crypto_auth_hmacsha512","_crypto_auth_hmacsha512_bytes","_crypto_auth_hmacsha512_final","_crypto_auth_hmacsha512_init","_crypto_auth_hmacsha512_keybytes","_crypto_auth_hmacsha512_keygen","_crypto_auth_hmacsha512_statebytes","_crypto_auth_hmacsha512_update","_crypto_auth_hmacsha512_verify","_crypto_auth_hmacsha512256","_crypto_auth_hmacsha512256_bytes","_crypto_auth_hmacsha512256_final","_crypto_auth_hmacsha512256_init","_crypto_auth_hmacsha512256_keybytes","_crypto_auth_hmacsha512256_keygen","_crypto_auth_hmacsha512256_statebytes","_crypto_auth_hmacsha512256_update","_crypto_auth_hmacsha512256_verify","_crypto_auth_keybytes","_crypto_auth_keygen","_crypto_auth_primitive","_crypto_auth_verify","_crypto_box","_crypto_box_afternm","_crypto_box_beforenm","_crypto_box_beforenmbytes","_crypto_box_boxzerobytes","_crypto_box_curve25519xchacha20poly1305_beforenm","_crypto_box_curve25519xchacha20poly1305_beforenmbytes","_crypto_box_curve25519xchacha20poly1305_detached","_crypto_box_curve25519xchacha20poly1305_detached_afternm","_crypto_box_curve25519xchacha20poly1305_easy","_crypto_box_curve25519xchacha20poly1305_easy_afternm","_crypto_box_curve25519xchacha20poly1305_keypair","_crypto_box_curve25519xchacha20poly1305_macbytes","_crypto_box_curve25519xchacha20poly1305_messagebytes_max","_crypto_box_curve25519xchacha20poly1305_noncebytes","_crypto_box_curve25519xchacha20poly1305_open_detached","_crypto_box_curve25519xchacha20poly1305_open_detached_afternm","_crypto_box_curve25519xchacha20poly1305_open_easy","_crypto_box_curve25519xchacha20poly1305_open_easy_afternm","_crypto_box_curve25519xchacha20poly1305_publickeybytes","_crypto_box_curve25519xchacha20poly1305_seal","_crypto_box_curve25519xchacha20poly1305_seal_open","_crypto_box_curve25519xchacha20poly1305_sealbytes","_crypto_box_curve25519xchacha20poly1305_secretkeybytes","_crypto_box_curve25519xchacha20poly1305_seed_keypair","_crypto_box_curve25519xchacha20poly1305_seedbytes","_crypto_box_curve25519xsalsa20poly1305","_crypto_box_curve25519xsalsa20poly1305_afternm","_crypto_box_curve25519xsalsa20poly1305_beforenm","_crypto_box_curve25519xsalsa20poly1305_beforenmbytes","_crypto_box_curve25519xsalsa20poly1305_boxzerobytes","_crypto_box_curve25519xsalsa20poly1305_keypair","_crypto_box_curve25519xsalsa20poly1305_macbytes","_crypto_box_curve25519xsalsa20poly1305_messagebytes_max","_crypto_box_curve25519xsalsa20poly1305_noncebytes","_crypto_box_curve25519xsalsa20poly1305_open","_crypto_box_curve25519xsalsa20poly1305_open_afternm","_crypto_box_curve25519xsalsa20poly1305_publickeybytes","_crypto_box_curve25519xsalsa20poly1305_secretkeybytes","_crypto_box_curve25519xsalsa20poly1305_seed_keypair","_crypto_box_curve25519xsalsa20poly1305_seedbytes","_crypto_box_curve25519xsalsa20poly1305_zerobytes","_crypto_box_detached","_crypto_box_detached_afternm","_crypto_box_easy","_crypto_box_easy_afternm","_crypto_box_keypair","_crypto_box_macbytes","_crypto_box_messagebytes_max","_crypto_box_noncebytes","_crypto_box_open","_crypto_box_open_afternm","_crypto_box_open_detached","_crypto_box_open_detached_afternm","_crypto_box_open_easy","_crypto_box_open_easy_afternm","_crypto_box_primitive","_crypto_box_publickeybytes","_crypto_box_seal","_crypto_box_seal_open","_crypto_box_sealbytes","_crypto_box_secretkeybytes","_crypto_box_seed_keypair","_crypto_box_seedbytes","_crypto_box_zerobytes","_crypto_core_ed25519_add","_crypto_core_ed25519_bytes","_crypto_core_ed25519_from_hash","_crypto_core_ed25519_from_uniform","_crypto_core_ed25519_hashbytes","_crypto_core_ed25519_is_valid_point","_crypto_core_ed25519_nonreducedscalarbytes","_crypto_core_ed25519_random","_crypto_core_ed25519_scalar_add","_crypto_core_ed25519_scalar_complement","_crypto_core_ed25519_scalar_invert","_crypto_core_ed25519_scalar_mul","_crypto_core_ed25519_scalar_negate","_crypto_core_ed25519_scalar_random","_crypto_core_ed25519_scalar_reduce","_crypto_core_ed25519_scalar_sub","_crypto_core_ed25519_scalarbytes","_crypto_core_ed25519_sub","_crypto_core_ed25519_uniformbytes","_crypto_core_hchacha20","_crypto_core_hchacha20_constbytes","_crypto_core_hchacha20_inputbytes","_crypto_core_hchacha20_keybytes","_crypto_core_hchacha20_outputbytes","_crypto_core_hsalsa20","_crypto_core_hsalsa20_constbytes","_crypto_core_hsalsa20_inputbytes","_crypto_core_hsalsa20_keybytes","_crypto_core_hsalsa20_outputbytes","_crypto_core_keccak1600_extract_bytes","_crypto_core_keccak1600_init","_crypto_core_keccak1600_permute_12","_crypto_core_keccak1600_permute_24","_crypto_core_keccak1600_statebytes","_crypto_core_keccak1600_xor_bytes","_crypto_core_ristretto255_add","_crypto_core_ristretto255_bytes","_crypto_core_ristretto255_from_hash","_crypto_core_ristretto255_hashbytes","_crypto_core_ristretto255_is_valid_point","_crypto_core_ristretto255_nonreducedscalarbytes","_crypto_core_ristretto255_random","_crypto_core_ristretto255_scalar_add","_crypto_core_ristretto255_scalar_complement","_crypto_core_ristretto255_scalar_invert","_crypto_core_ristretto255_scalar_mul","_crypto_core_ristretto255_scalar_negate","_crypto_core_ristretto255_scalar_random","_crypto_core_ristretto255_scalar_reduce","_crypto_core_ristretto255_scalar_sub","_crypto_core_ristretto255_scalarbytes","_crypto_core_ristretto255_sub","_crypto_core_salsa20","_crypto_core_salsa20_constbytes","_crypto_core_salsa20_inputbytes","_crypto_core_salsa20_keybytes","_crypto_core_salsa20_outputbytes","_crypto_core_salsa2012","_crypto_core_salsa2012_constbytes","_crypto_core_salsa2012_inputbytes","_crypto_core_salsa2012_keybytes","_crypto_core_salsa2012_outputbytes","_crypto_core_salsa208","_crypto_core_salsa208_constbytes","_crypto_core_salsa208_inputbytes","_crypto_core_salsa208_keybytes","_crypto_core_salsa208_outputbytes","_crypto_generichash","_crypto_generichash_blake2b","_crypto_generichash_blake2b_bytes","_crypto_generichash_blake2b_bytes_max","_crypto_generichash_blake2b_bytes_min","_crypto_generichash_blake2b_final","_crypto_generichash_blake2b_init","_crypto_generichash_blake2b_init_salt_personal","_crypto_generichash_blake2b_keybytes","_crypto_generichash_blake2b_keybytes_max","_crypto_generichash_blake2b_keybytes_min","_crypto_generichash_blake2b_keygen","_crypto_generichash_blake2b_personalbytes","_crypto_generichash_blake2b_salt_personal","_crypto_generichash_blake2b_saltbytes","_crypto_generichash_blake2b_statebytes","_crypto_generichash_blake2b_update","_crypto_generichash_bytes","_crypto_generichash_bytes_max","_crypto_generichash_bytes_min","_crypto_generichash_final","_crypto_generichash_init","_crypto_generichash_keybytes","_crypto_generichash_keybytes_max","_crypto_generichash_keybytes_min","_crypto_generichash_keygen","_crypto_generichash_primitive","_crypto_generichash_statebytes","_crypto_generichash_update","_crypto_hash","_crypto_hash_bytes","_crypto_hash_primitive","_crypto_hash_sha256","_crypto_hash_sha256_bytes","_crypto_hash_sha256_final","_crypto_hash_sha256_init","_crypto_hash_sha256_statebytes","_crypto_hash_sha256_update","_crypto_hash_sha3256","_crypto_hash_sha3256_bytes","_crypto_hash_sha3256_final","_crypto_hash_sha3256_init","_crypto_hash_sha3256_statebytes","_crypto_hash_sha3256_update","_crypto_hash_sha3512","_crypto_hash_sha3512_bytes","_crypto_hash_sha3512_final","_crypto_hash_sha3512_init","_crypto_hash_sha3512_statebytes","_crypto_hash_sha3512_update","_crypto_hash_sha512","_crypto_hash_sha512_bytes","_crypto_hash_sha512_final","_crypto_hash_sha512_init","_crypto_hash_sha512_statebytes","_crypto_hash_sha512_update","_crypto_ipcrypt_bytes","_crypto_ipcrypt_decrypt","_crypto_ipcrypt_encrypt","_crypto_ipcrypt_keybytes","_crypto_ipcrypt_keygen","_crypto_ipcrypt_nd_decrypt","_crypto_ipcrypt_nd_encrypt","_crypto_ipcrypt_nd_inputbytes","_crypto_ipcrypt_nd_keybytes","_crypto_ipcrypt_nd_keygen","_crypto_ipcrypt_nd_outputbytes","_crypto_ipcrypt_nd_tweakbytes","_crypto_ipcrypt_ndx_decrypt","_crypto_ipcrypt_ndx_encrypt","_crypto_ipcrypt_ndx_inputbytes","_crypto_ipcrypt_ndx_keybytes","_crypto_ipcrypt_ndx_keygen","_crypto_ipcrypt_ndx_outputbytes","_crypto_ipcrypt_ndx_tweakbytes","_crypto_ipcrypt_pfx_bytes","_crypto_ipcrypt_pfx_decrypt","_crypto_ipcrypt_pfx_encrypt","_crypto_ipcrypt_pfx_keybytes","_crypto_ipcrypt_pfx_keygen","_crypto_kdf_blake2b_bytes_max","_crypto_kdf_blake2b_bytes_min","_crypto_kdf_blake2b_contextbytes","_crypto_kdf_blake2b_derive_from_key","_crypto_kdf_blake2b_keybytes","_crypto_kdf_bytes_max","_crypto_kdf_bytes_min","_crypto_kdf_contextbytes","_crypto_kdf_derive_from_key","_crypto_kdf_hkdf_sha256_bytes_max","_crypto_kdf_hkdf_sha256_bytes_min","_crypto_kdf_hkdf_sha256_expand","_crypto_kdf_hkdf_sha256_extract","_crypto_kdf_hkdf_sha256_extract_final","_crypto_kdf_hkdf_sha256_extract_init","_crypto_kdf_hkdf_sha256_extract_update","_crypto_kdf_hkdf_sha256_keybytes","_crypto_kdf_hkdf_sha256_keygen","_crypto_kdf_hkdf_sha256_statebytes","_crypto_kdf_hkdf_sha512_bytes_max","_crypto_kdf_hkdf_sha512_bytes_min","_crypto_kdf_hkdf_sha512_expand","_crypto_kdf_hkdf_sha512_extract","_crypto_kdf_hkdf_sha512_extract_final","_crypto_kdf_hkdf_sha512_extract_init","_crypto_kdf_hkdf_sha512_extract_update","_crypto_kdf_hkdf_sha512_keybytes","_crypto_kdf_hkdf_sha512_keygen","_crypto_kdf_hkdf_sha512_statebytes","_crypto_kdf_keybytes","_crypto_kdf_keygen","_crypto_kdf_primitive","_crypto_kem_ciphertextbytes","_crypto_kem_dec","_crypto_kem_enc","_crypto_kem_keypair","_crypto_kem_mlkem768_ciphertextbytes","_crypto_kem_mlkem768_dec","_crypto_kem_mlkem768_enc","_crypto_kem_mlkem768_enc_deterministic","_crypto_kem_mlkem768_keypair","_crypto_kem_mlkem768_publickeybytes","_crypto_kem_mlkem768_secretkeybytes","_crypto_kem_mlkem768_seed_keypair","_crypto_kem_mlkem768_seedbytes","_crypto_kem_mlkem768_sharedsecretbytes","_crypto_kem_primitive","_crypto_kem_publickeybytes","_crypto_kem_secretkeybytes","_crypto_kem_seed_keypair","_crypto_kem_seedbytes","_crypto_kem_sharedsecretbytes","_crypto_kem_xwing_ciphertextbytes","_crypto_kem_xwing_dec","_crypto_kem_xwing_enc","_crypto_kem_xwing_enc_deterministic","_crypto_kem_xwing_keypair","_crypto_kem_xwing_publickeybytes","_crypto_kem_xwing_secretkeybytes","_crypto_kem_xwing_seed_keypair","_crypto_kem_xwing_seedbytes","_crypto_kem_xwing_sharedsecretbytes","_crypto_kx_client_session_keys","_crypto_kx_keypair","_crypto_kx_primitive","_crypto_kx_publickeybytes","_crypto_kx_secretkeybytes","_crypto_kx_seed_keypair","_crypto_kx_seedbytes","_crypto_kx_server_session_keys","_crypto_kx_sessionkeybytes","_crypto_onetimeauth","_crypto_onetimeauth_bytes","_crypto_onetimeauth_final","_crypto_onetimeauth_init","_crypto_onetimeauth_keybytes","_crypto_onetimeauth_keygen","_crypto_onetimeauth_poly1305","_crypto_onetimeauth_poly1305_bytes","_crypto_onetimeauth_poly1305_final","_crypto_onetimeauth_poly1305_init","_crypto_onetimeauth_poly1305_keybytes","_crypto_onetimeauth_poly1305_keygen","_crypto_onetimeauth_poly1305_statebytes","_crypto_onetimeauth_poly1305_update","_crypto_onetimeauth_poly1305_verify","_crypto_onetimeauth_primitive","_crypto_onetimeauth_statebytes","_crypto_onetimeauth_update","_crypto_onetimeauth_verify","_crypto_pwhash","_crypto_pwhash_alg_argon2i13","_crypto_pwhash_alg_argon2id13","_crypto_pwhash_alg_default","_crypto_pwhash_argon2i","_crypto_pwhash_argon2i_alg_argon2i13","_crypto_pwhash_argon2i_bytes_max","_crypto_pwhash_argon2i_bytes_min","_crypto_pwhash_argon2i_memlimit_interactive","_crypto_pwhash_argon2i_memlimit_max","_crypto_pwhash_argon2i_memlimit_min","_crypto_pwhash_argon2i_memlimit_moderate","_crypto_pwhash_argon2i_memlimit_sensitive","_crypto_pwhash_argon2i_opslimit_interactive","_crypto_pwhash_argon2i_opslimit_max","_crypto_pwhash_argon2i_opslimit_min","_crypto_pwhash_argon2i_opslimit_moderate","_crypto_pwhash_argon2i_opslimit_sensitive","_crypto_pwhash_argon2i_passwd_max","_crypto_pwhash_argon2i_passwd_min","_crypto_pwhash_argon2i_saltbytes","_crypto_pwhash_argon2i_str","_crypto_pwhash_argon2i_str_needs_rehash","_crypto_pwhash_argon2i_str_verify","_crypto_pwhash_argon2i_strbytes","_crypto_pwhash_argon2i_strprefix","_crypto_pwhash_argon2id","_crypto_pwhash_argon2id_alg_argon2id13","_crypto_pwhash_argon2id_bytes_max","_crypto_pwhash_argon2id_bytes_min","_crypto_pwhash_argon2id_memlimit_interactive","_crypto_pwhash_argon2id_memlimit_max","_crypto_pwhash_argon2id_memlimit_min","_crypto_pwhash_argon2id_memlimit_moderate","_crypto_pwhash_argon2id_memlimit_sensitive","_crypto_pwhash_argon2id_opslimit_interactive","_crypto_pwhash_argon2id_opslimit_max","_crypto_pwhash_argon2id_opslimit_min","_crypto_pwhash_argon2id_opslimit_moderate","_crypto_pwhash_argon2id_opslimit_sensitive","_crypto_pwhash_argon2id_passwd_max","_crypto_pwhash_argon2id_passwd_min","_crypto_pwhash_argon2id_saltbytes","_crypto_pwhash_argon2id_str","_crypto_pwhash_argon2id_str_needs_rehash","_crypto_pwhash_argon2id_str_verify","_crypto_pwhash_argon2id_strbytes","_crypto_pwhash_argon2id_strprefix","_crypto_pwhash_bytes_max","_crypto_pwhash_bytes_min","_crypto_pwhash_memlimit_interactive","_crypto_pwhash_memlimit_max","_crypto_pwhash_memlimit_min","_crypto_pwhash_memlimit_moderate","_crypto_pwhash_memlimit_sensitive","_crypto_pwhash_opslimit_interactive","_crypto_pwhash_opslimit_max","_crypto_pwhash_opslimit_min","_crypto_pwhash_opslimit_moderate","_crypto_pwhash_opslimit_sensitive","_crypto_pwhash_passwd_max","_crypto_pwhash_passwd_min","_crypto_pwhash_primitive","_crypto_pwhash_saltbytes","_crypto_pwhash_scryptsalsa208sha256","_crypto_pwhash_scryptsalsa208sha256_bytes_max","_crypto_pwhash_scryptsalsa208sha256_bytes_min","_crypto_pwhash_scryptsalsa208sha256_ll","_crypto_pwhash_scryptsalsa208sha256_memlimit_interactive","_crypto_pwhash_scryptsalsa208sha256_memlimit_max","_crypto_pwhash_scryptsalsa208sha256_memlimit_min","_crypto_pwhash_scryptsalsa208sha256_memlimit_sensitive","_crypto_pwhash_scryptsalsa208sha256_opslimit_interactive","_crypto_pwhash_scryptsalsa208sha256_opslimit_max","_crypto_pwhash_scryptsalsa208sha256_opslimit_min","_crypto_pwhash_scryptsalsa208sha256_opslimit_sensitive","_crypto_pwhash_scryptsalsa208sha256_passwd_max","_crypto_pwhash_scryptsalsa208sha256_passwd_min","_crypto_pwhash_scryptsalsa208sha256_saltbytes","_crypto_pwhash_scryptsalsa208sha256_str","_crypto_pwhash_scryptsalsa208sha256_str_needs_rehash","_crypto_pwhash_scryptsalsa208sha256_str_verify","_crypto_pwhash_scryptsalsa208sha256_strbytes","_crypto_pwhash_scryptsalsa208sha256_strprefix","_crypto_pwhash_str","_crypto_pwhash_str_alg","_crypto_pwhash_str_needs_rehash","_crypto_pwhash_str_verify","_crypto_pwhash_strbytes","_crypto_pwhash_strprefix","_crypto_scalarmult","_crypto_scalarmult_base","_crypto_scalarmult_bytes","_crypto_scalarmult_curve25519","_crypto_scalarmult_curve25519_base","_crypto_scalarmult_curve25519_bytes","_crypto_scalarmult_curve25519_scalarbytes","_crypto_scalarmult_ed25519","_crypto_scalarmult_ed25519_base","_crypto_scalarmult_ed25519_base_noclamp","_crypto_scalarmult_ed25519_bytes","_crypto_scalarmult_ed25519_noclamp","_crypto_scalarmult_ed25519_scalarbytes","_crypto_scalarmult_primitive","_crypto_scalarmult_ristretto255","_crypto_scalarmult_ristretto255_base","_crypto_scalarmult_ristretto255_bytes","_crypto_scalarmult_ristretto255_scalarbytes","_crypto_scalarmult_scalarbytes","_crypto_secretbox","_crypto_secretbox_boxzerobytes","_crypto_secretbox_detached","_crypto_secretbox_easy","_crypto_secretbox_keybytes","_crypto_secretbox_keygen","_crypto_secretbox_macbytes","_crypto_secretbox_messagebytes_max","_crypto_secretbox_noncebytes","_crypto_secretbox_open","_crypto_secretbox_open_detached","_crypto_secretbox_open_easy","_crypto_secretbox_primitive","_crypto_secretbox_xchacha20poly1305_detached","_crypto_secretbox_xchacha20poly1305_easy","_crypto_secretbox_xchacha20poly1305_keybytes","_crypto_secretbox_xchacha20poly1305_macbytes","_crypto_secretbox_xchacha20poly1305_messagebytes_max","_crypto_secretbox_xchacha20poly1305_noncebytes","_crypto_secretbox_xchacha20poly1305_open_detached","_crypto_secretbox_xchacha20poly1305_open_easy","_crypto_secretbox_xsalsa20poly1305","_crypto_secretbox_xsalsa20poly1305_boxzerobytes","_crypto_secretbox_xsalsa20poly1305_keybytes","_crypto_secretbox_xsalsa20poly1305_keygen","_crypto_secretbox_xsalsa20poly1305_macbytes","_crypto_secretbox_xsalsa20poly1305_messagebytes_max","_crypto_secretbox_xsalsa20poly1305_noncebytes","_crypto_secretbox_xsalsa20poly1305_open","_crypto_secretbox_xsalsa20poly1305_zerobytes","_crypto_secretbox_zerobytes","_crypto_secretstream_xchacha20poly1305_abytes","_crypto_secretstream_xchacha20poly1305_headerbytes","_crypto_secretstream_xchacha20poly1305_init_pull","_crypto_secretstream_xchacha20poly1305_init_push","_crypto_secretstream_xchacha20poly1305_keybytes","_crypto_secretstream_xchacha20poly1305_keygen","_crypto_secretstream_xchacha20poly1305_messagebytes_max","_crypto_secretstream_xchacha20poly1305_pull","_crypto_secretstream_xchacha20poly1305_push","_crypto_secretstream_xchacha20poly1305_rekey","_crypto_secretstream_xchacha20poly1305_statebytes","_crypto_secretstream_xchacha20poly1305_tag_final","_crypto_secretstream_xchacha20poly1305_tag_message","_crypto_secretstream_xchacha20poly1305_tag_push","_crypto_secretstream_xchacha20poly1305_tag_rekey","_crypto_shorthash","_crypto_shorthash_bytes","_crypto_shorthash_keybytes","_crypto_shorthash_keygen","_crypto_shorthash_primitive","_crypto_shorthash_siphash24","_crypto_shorthash_siphash24_bytes","_crypto_shorthash_siphash24_keybytes","_crypto_shorthash_siphashx24","_crypto_shorthash_siphashx24_bytes","_crypto_shorthash_siphashx24_keybytes","_crypto_sign","_crypto_sign_bytes","_crypto_sign_detached","_crypto_sign_ed25519","_crypto_sign_ed25519_bytes","_crypto_sign_ed25519_detached","_crypto_sign_ed25519_keypair","_crypto_sign_ed25519_messagebytes_max","_crypto_sign_ed25519_open","_crypto_sign_ed25519_pk_to_curve25519","_crypto_sign_ed25519_publickeybytes","_crypto_sign_ed25519_secretkeybytes","_crypto_sign_ed25519_seed_keypair","_crypto_sign_ed25519_seedbytes","_crypto_sign_ed25519_sk_to_curve25519","_crypto_sign_ed25519_sk_to_pk","_crypto_sign_ed25519_sk_to_seed","_crypto_sign_ed25519_verify_detached","_crypto_sign_ed25519ph_final_create","_crypto_sign_ed25519ph_final_verify","_crypto_sign_ed25519ph_init","_crypto_sign_ed25519ph_statebytes","_crypto_sign_ed25519ph_update","_crypto_sign_edwards25519sha512batch","_crypto_sign_edwards25519sha512batch_keypair","_crypto_sign_edwards25519sha512batch_open","_crypto_sign_final_create","_crypto_sign_final_verify","_crypto_sign_init","_crypto_sign_keypair","_crypto_sign_messagebytes_max","_crypto_sign_open","_crypto_sign_primitive","_crypto_sign_publickeybytes","_crypto_sign_secretkeybytes","_crypto_sign_seed_keypair","_crypto_sign_seedbytes","_crypto_sign_statebytes","_crypto_sign_update","_crypto_sign_verify_detached","_crypto_stream","_crypto_stream_chacha20","_crypto_stream_chacha20_ietf","_crypto_stream_chacha20_ietf_keybytes","_crypto_stream_chacha20_ietf_keygen","_crypto_stream_chacha20_ietf_messagebytes_max","_crypto_stream_chacha20_ietf_noncebytes","_crypto_stream_chacha20_ietf_xor","_crypto_stream_chacha20_ietf_xor_ic","_crypto_stream_chacha20_keybytes","_crypto_stream_chacha20_keygen","_crypto_stream_chacha20_messagebytes_max","_crypto_stream_chacha20_noncebytes","_crypto_stream_chacha20_xor","_crypto_stream_chacha20_xor_ic","_crypto_stream_keybytes","_crypto_stream_keygen","_crypto_stream_messagebytes_max","_crypto_stream_noncebytes","_crypto_stream_primitive","_crypto_stream_salsa20","_crypto_stream_salsa20_keybytes","_crypto_stream_salsa20_keygen","_crypto_stream_salsa20_messagebytes_max","_crypto_stream_salsa20_noncebytes","_crypto_stream_salsa20_xor","_crypto_stream_salsa20_xor_ic","_crypto_stream_salsa2012","_crypto_stream_salsa2012_keybytes","_crypto_stream_salsa2012_keygen","_crypto_stream_salsa2012_messagebytes_max","_crypto_stream_salsa2012_noncebytes","_crypto_stream_salsa2012_xor","_crypto_stream_salsa208","_crypto_stream_salsa208_keybytes","_crypto_stream_salsa208_keygen","_crypto_stream_salsa208_messagebytes_max","_crypto_stream_salsa208_noncebytes","_crypto_stream_salsa208_xor","_crypto_stream_xchacha20","_crypto_stream_xchacha20_keybytes","_crypto_stream_xchacha20_keygen","_crypto_stream_xchacha20_messagebytes_max","_crypto_stream_xchacha20_noncebytes","_crypto_stream_xchacha20_xor","_crypto_stream_xchacha20_xor_ic","_crypto_stream_xor","_crypto_stream_xsalsa20","_crypto_stream_xsalsa20_keybytes","_crypto_stream_xsalsa20_keygen","_crypto_stream_xsalsa20_messagebytes_max","_crypto_stream_xsalsa20_noncebytes","_crypto_stream_xsalsa20_xor","_crypto_stream_xsalsa20_xor_ic","_crypto_verify_16","_crypto_verify_16_bytes","_crypto_verify_32","_crypto_verify_32_bytes","_crypto_verify_64","_crypto_verify_64_bytes","_crypto_xof_shake128","_crypto_xof_shake128_blockbytes","_crypto_xof_shake128_domain_standard","_crypto_xof_shake128_init","_crypto_xof_shake128_init_with_domain","_crypto_xof_shake128_squeeze","_crypto_xof_shake128_statebytes","_crypto_xof_shake128_update","_crypto_xof_shake256","_crypto_xof_shake256_blockbytes","_crypto_xof_shake256_domain_standard","_crypto_xof_shake256_init","_crypto_xof_shake256_init_with_domain","_crypto_xof_shake256_squeeze","_crypto_xof_shake256_statebytes","_crypto_xof_shake256_update","_crypto_xof_turboshake128","_crypto_xof_turboshake128_blockbytes","_crypto_xof_turboshake128_domain_standard","_crypto_xof_turboshake128_init","_crypto_xof_turboshake128_init_with_domain","_crypto_xof_turboshake128_squeeze","_crypto_xof_turboshake128_statebytes","_crypto_xof_turboshake128_update","_crypto_xof_turboshake256","_crypto_xof_turboshake256_blockbytes","_crypto_xof_turboshake256_domain_standard","_crypto_xof_turboshake256_init","_crypto_xof_turboshake256_init_with_domain","_crypto_xof_turboshake256_squeeze","_crypto_xof_turboshake256_statebytes","_crypto_xof_turboshake256_update","_randombytes","_randombytes_buf","_randombytes_buf_deterministic","_randombytes_close","_randombytes_implementation_name","_randombytes_random","_randombytes_seedbytes","_randombytes_stir","_randombytes_uniform","_sodium_base64_encoded_len","_sodium_base642bin","_sodium_bin2base64","_sodium_bin2hex","_sodium_bin2ip","_sodium_hex2bin","_sodium_init","_sodium_ip2bin","_sodium_library_minimal","_sodium_library_version_major","_sodium_library_version_minor","_sodium_pad","_sodium_unpad","_sodium_version_string"]'
export EXPORTED_RUNTIME_METHODS='["UTF8ToString","getValue","setValue","HEAPU8"]'
export JS_RESERVED_MEMORY_STANDARD=16MB
export JS_RESERVED_MEMORY_SUMO=80MB
export JS_RESERVED_MEMORY_TESTS=16MB
export WASM_INITIAL_MEMORY=4MB
export LDFLAGS="-sALLOW_TABLE_GROWTH"
export LDFLAGS="${LDFLAGS} -s ALLOW_MEMORY_GROWTH=1"
export LDFLAGS="${LDFLAGS} -s SINGLE_FILE=1 -s SINGLE_FILE_BINARY_ENCODE=0"
export LDFLAGS="${LDFLAGS} -s ASSERTIONS=0"
export LDFLAGS="${LDFLAGS} -s DISABLE_EXCEPTION_CATCHING=1"
export LDFLAGS="${LDFLAGS} -s NODEJS_CATCH_EXIT=0"
export LDFLAGS="${LDFLAGS} -s NODEJS_CATCH_REJECTION=0"
export LDFLAGS="${LDFLAGS} -s WASM_BIGINT=0"

# Parse arguments
BUILD_TYPE=""
ENABLE_SIMD="no"

for arg in "$@"; do
  case "$arg" in
    --standard|--sumo|--browser-tests|--tests)
      BUILD_TYPE="$arg"
      ;;
    --simd)
      ENABLE_SIMD="yes"
      ;;
    *)
      echo "Unknown argument: $arg"
      echo "Usage: $0 <build_type> [--simd]"
      echo "<build_type> := --standard | --sumo | --browser-tests | --tests"
      echo "Options:"
      echo "  --simd    Enable WebAssembly SIMD128 (faster Argon2, requires WASM SIMD support)"
      echo
      exit 1
      ;;
  esac
done

echo
if [ "$BUILD_TYPE" = "--standard" ]; then
  export EXPORTED_FUNCTIONS="$EXPORTED_FUNCTIONS_STANDARD"
  export LDFLAGS="${LDFLAGS} ${LDFLAGS_DIST}"
  export LDFLAGS_JS="-s TOTAL_MEMORY=${JS_RESERVED_MEMORY_STANDARD}"
  export PREFIX="$(pwd)/libsodium-js"
  export DONE_FILE="$(pwd)/js.done"
  export CONFIG_EXTRA="--enable-minimal"
  export DIST='yes'
  echo "Building a standard distribution in [${PREFIX}]"
elif [ "$BUILD_TYPE" = "--sumo" ]; then
  export EXPORTED_FUNCTIONS="$EXPORTED_FUNCTIONS_SUMO"
  export LDFLAGS="${LDFLAGS} ${LDFLAGS_DIST}"
  export LDFLAGS_JS="-s TOTAL_MEMORY=${JS_RESERVED_MEMORY_SUMO}"
  export PREFIX="$(pwd)/libsodium-js-sumo"
  export DONE_FILE="$(pwd)/js-sumo.done"
  export DIST='yes'
  echo "Building a sumo distribution in [${PREFIX}]"
elif [ "$BUILD_TYPE" = "--browser-tests" ]; then
  export EXPORTED_FUNCTIONS="$EXPORTED_FUNCTIONS_SUMO"
  export CPPFLAGS="${CPPFLAGS} -s FORCE_FILESYSTEM=1"
  export LDFLAGS="${LDFLAGS}"
  export LDFLAGS_JS="-s TOTAL_MEMORY=${JS_RESERVED_MEMORY_TESTS}"
  export PREFIX="$(pwd)/libsodium-js-tests"
  export DONE_FILE="$(pwd)/js-tests-browser.done"
  export BROWSER_TESTS='yes'
  export DIST='no'
  echo "Building tests for web browsers in [${PREFIX}]"
elif [ "$BUILD_TYPE" = "--tests" ]; then
  echo "Building for testing"
  export EXPORTED_FUNCTIONS="$EXPORTED_FUNCTIONS_SUMO"
  export CPPFLAGS="${CPPFLAGS} -s FORCE_FILESYSTEM=1 -DBENCHMARKS -DITERATIONS=10"
  export LDFLAGS="${LDFLAGS}"
  export LDFLAGS_JS="-s TOTAL_MEMORY=${JS_RESERVED_MEMORY_TESTS}"
  export PREFIX="$(pwd)/libsodium-js-tests"
  export DONE_FILE="$(pwd)/js-tests.done"
  export DIST='no'
  echo "Building for testing in [${PREFIX}]"
else
  echo "Usage: $0 <build_type> [--simd]"
  echo "<build_type> := --standard | --sumo | --browser-tests | --tests"
  echo "Options:"
  echo "  --simd    Enable WebAssembly SIMD128 (faster Argon2, requires WASM SIMD support)"
  echo
  exit 1
fi

if [ "$ENABLE_SIMD" = "yes" ]; then
  echo "SIMD128 enabled"
fi
export JS_EXPORTS_FLAGS="-s EXPORTED_FUNCTIONS=${EXPORTED_FUNCTIONS} -s EXPORTED_RUNTIME_METHODS=${EXPORTED_RUNTIME_METHODS}"

rm -f "$DONE_FILE"

echo

if [ "$ENABLE_SIMD" = "yes" ]; then
  export SIMD_CFLAGS="-msimd128"
else
  export SIMD_CFLAGS=""
fi

# First build without SIMD for asm.js fallback (always needed)
emconfigure ./configure $CONFIG_EXTRA --disable-shared --prefix="$PREFIX" \
  --without-pthreads \
  --disable-ssp --disable-asm --disable-pie &&
  emmake make clean
[ $? = 0 ] || exit 1

if [ "$DIST" = yes ]; then
  emccLibsodium() {
    outFile="${1}"
    shift
    emcc $CPPFLAGS $LDFLAGS $JS_EXPORTS_FLAGS "${@}" \
      "${PREFIX}/lib/libsodium.a" -o "${outFile}" || exit 1
  }
  emmake make $MAKE_FLAGS install || exit 1

  # Build asm.js fallback (without SIMD)
  emccLibsodium "${PREFIX}/lib/libsodium.asm.tmp.js" -Oz -s WASM=0 $LDFLAGS_JS

  if [ "$ENABLE_SIMD" = "yes" ]; then
    # Rebuild with SIMD for WASM
    emmake make clean
    export CFLAGS="${CFLAGS:+$CFLAGS }${SIMD_CFLAGS}"
    emmake make $MAKE_FLAGS install || exit 1
  fi

  # Build WASM (with SIMD if enabled)
  emccLibsodium "${PREFIX}/lib/libsodium.wasm.tmp.js" -O3 ${SIMD_CFLAGS} -s WASM=1 -s EVAL_CTORS=2 -s INITIAL_MEMORY=${WASM_INITIAL_MEMORY}

  # Build the output file by concatenating parts to preserve null bytes
  # (command substitution in heredoc strips null bytes from WASM binary)
  #
  # Structure:
  # 1. pre.tmp.js - module header, opens useBackupModule function
  # 2. asm.tmp.js - asm.js backup code (INSIDE useBackupModule)
  # 3. mid.tmp.js - closes useBackupModule, starts outer scope for WASM
  # 4. wasm.tmp.js - real WASM code (OUTSIDE useBackupModule, at Module.ready level)
  # 5. end.tmp.js - closes Module.ready promise with fallback

  cat >"${PREFIX}/lib/libsodium.pre.tmp.js" <<'PREJS'
    var Module;
    if (typeof Module === 'undefined') {
      Module = {};
    }
    var root = Module;
    if (typeof root['sodium'] !== 'object') {
      if (typeof global === 'object') {
        root = global;
      } else if (typeof window === 'object') {
        root = window;
      }
    }
    if (typeof Module.getRandomValue === 'undefined') {
      try {
        var window_ = 'object' === typeof window ? window : self;
        var crypto_ = typeof window_.crypto !== 'undefined' ? window_.crypto : window_.msCrypto;
        var randomValuesStandard = function() {
          var buf = new Uint32Array(1);
          crypto_.getRandomValues(buf);
          return buf[0] >>> 0;
        };
        randomValuesStandard();
        Module.getRandomValue = randomValuesStandard;
      } catch (e) {
        try {
          var crypto = require('crypto');
          var randomValueNodeJS = function() {
            var buf = crypto['randomBytes'](4);
            return (buf[0] << 24 | buf[1] << 16 | buf[2] << 8 | buf[3]) >>> 0;
          };
          randomValueNodeJS();
          Module.getRandomValue = randomValueNodeJS;
        } catch (e) {
          throw 'No secure random number generator found';
        }
      }
    }
    var _Module = Module;
    Module.ready = new Promise(function(resolve, reject) {
      var Module = _Module;
      Module.onAbort = reject;
      Module.print = function(what) {
        typeof(console) !== 'undefined' && console.log(what);
      }
      Module.printErr = function(what) {
        typeof(console) !== 'undefined' && console.warn(what);
      }
      Module.onRuntimeInitialized = function() {
        try {
          /* Test arbitrary wasm function */
          Module._crypto_secretbox_keybytes();
          resolve();
        } catch (err) {
          reject(err);
        }
      };
      Module.useBackupModule = function() {
        return new Promise(function(resolve, reject) {
          var Module = {};
          Module.onAbort = reject;
          Module.getRandomValue = _Module.getRandomValue;

          Module.onRuntimeInitialized = function() {
            Object.keys(_Module).forEach(function(k) {
              if (k !== 'getRandomValue') {
                delete _Module[k];
              }
            });
            Object.keys(Module).forEach(function(k) {
              _Module[k] = Module[k];
            });
            resolve();
          };

PREJS

  cat >"${PREFIX}/lib/libsodium.mid.tmp.js" <<'MIDJS'
        });
      };
MIDJS

  cat >"${PREFIX}/lib/libsodium.end.tmp.js" <<'ENDJS'
    }).catch(function() {
      return _Module.useBackupModule();
    });
ENDJS

  # Concatenate all parts, preserving binary content
  # Note: asm.js goes inside useBackupModule, wasm.js goes outside at Module.ready level
  cat "${PREFIX}/lib/libsodium.pre.tmp.js" > "${PREFIX}/lib/libsodium.js"
  sed "s|use asm||g" "${PREFIX}/lib/libsodium.asm.tmp.js" >> "${PREFIX}/lib/libsodium.js"
  cat "${PREFIX}/lib/libsodium.mid.tmp.js" >> "${PREFIX}/lib/libsodium.js"
  cat "${PREFIX}/lib/libsodium.wasm.tmp.js" >> "${PREFIX}/lib/libsodium.js"
  cat "${PREFIX}/lib/libsodium.end.tmp.js" >> "${PREFIX}/lib/libsodium.js"

  rm "${PREFIX}/lib/libsodium.pre.tmp.js" "${PREFIX}/lib/libsodium.mid.tmp.js" "${PREFIX}/lib/libsodium.end.tmp.js"

  # Build native ESM module (WASM-only, factory pattern, no asm.js fallback)
  emccLibsodium "${PREFIX}/lib/libsodium.esm.mjs" -O3 ${SIMD_CFLAGS} \
    -s WASM=1 -s EVAL_CTORS=2 -s INITIAL_MEMORY=${WASM_INITIAL_MEMORY} \
    -s MODULARIZE=1 -s EXPORT_ES6=1 -s EXPORT_NAME=createLibsodium \
    -s ENVIRONMENT=web,worker

  touch -r "${PREFIX}/lib/libsodium.js" "$DONE_FILE"
  ls -l "${PREFIX}/lib/libsodium.js" "${PREFIX}/lib/libsodium.esm.mjs"
  exit 0
fi

if test "$JS_RUNTIME" = ""; then
  for candidate in bun nodejs node /usr/local/bin/bun /usr/local/bin/nodejs /usr/local/bin/node; do
    if command -v $candidate >/dev/null; then
      JS_RUNTIME=$candidate
      break
    fi
  done
fi

find test/default -type f -name '*.js' -exec rm -f {} \;

if [ "x$BROWSER_TESTS" != "x" ]; then
  echo 'Compiling the test suite for web browsers...' &&
    emmake make $MAKE_FLAGS CPPFLAGS="$CPPFLAGS -DBROWSER_TESTS=1" check >/dev/null 2>&1
else
  if test "$JS_RUNTIME" = ""; then
    echo 'Javascript runtime not found - test suite skipped' >&2
    exit 1
  fi
  echo "Using [${JS_RUNTIME}] as a Javascript runtime"
  echo 'Compiling the test suite...' &&
    emmake make $MAKE_FLAGS check >/dev/null 2>&1
fi

if [ "x$BROWSER_TESTS" != "x" ]; then
  echo 'Creating the test suite for web browsers'
  (
    cd test/default &&
      mkdir -p browser &&
      rm -f browser/tests.txt &&
      for file in *.js; do
        cp "$file" "browser/${file}"
        tname=$(echo "$file" | sed 's/.js$//')
        cp -f "${tname}.exp" "browser/${tname}.exp"
        sed "s/{{tname}}/${tname}/" index.html.tpl >"browser/${tname}.html"
        echo "${tname}.html" >>"browser/tests.txt"
      done
    touch "$DONE_FILE"
  )
else
  echo 'Running the test suite'
  (
    cd test/default &&
      for file in *.js; do
        echo "#! /usr/bin/env ${JS_RUNTIME}" >"${file}.tmp"
        cat "$file" >> "${file}.tmp"
        chmod +x "${file}.tmp"
        mv -f "${file}.tmp" "$file"
      done
  )
  make $MAKE_FLAGS check || exit 1
  touch "$DONE_FILE"
fi

echo 'Done.'
